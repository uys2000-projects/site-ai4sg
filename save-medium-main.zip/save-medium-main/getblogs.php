<?php

require "database.php";

header('Content-Type: text/json; charset=utf-8; lang=tr');

$db = new Database();

$data = $db->result("timestamp", "*", "blogs", null, null, null);

echo json_encode($data);
?>