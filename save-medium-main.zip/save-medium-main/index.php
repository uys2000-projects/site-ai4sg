<?php

require __DIR__ . '/vendor/autoload.php';
require "database.php";

header('Content-Type: text/json; charset=utf-8; lang=tr');

if (!ini_get('date.timezone')) {
	date_default_timezone_set('Europe/Istanbul');
}

$db = new Database();

$feed = new Feed();
$rss = $feed->loadRss('https://medium.com/feed/@aiforsg');

foreach ($rss->item as $item){
	$dbItem = $db->row("*", "blogs", array("timestamp" => $item->timestamp));
	if (!$dbItem){
		$db->insert("blogs", array(
			"timestamp" => $item->timestamp,
			"title" => $item->title,
			"link" => $item->link,
			"guid" => $item->guid,
			"category" => json_encode($item->category),
			"pubDate" => $item->pubDate,
			"creator" => $item->{"dc:creator"},
			"updated" => $item->{"atom:updated"},
			"content" => $item->{"content:encoded"}
		));
	}
}
?>