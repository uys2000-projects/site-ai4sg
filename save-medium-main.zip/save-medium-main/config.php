<?php

    /* DATABASE CONFIGS */
    $dbHost = "localhost";
    $dbName = "club_website";
    $dbUserName = "root";
    $dbPass = "root";

?>