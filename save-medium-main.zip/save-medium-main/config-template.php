<?php

    /* DATABASE CONFIGS */
    $dbHost = "localhost";
    $dbName = "";
    $dbUserName = "";
    $dbPass = "";

?>